# Spring Boot Microservices (BookMyFood)

Run `mvn spring-boot:run` in each module folder.
Ensure MySQL running with DBs: users_db, food_db, order_db, payment_db.
Start order: eureka-server -> user-management, food-service, order-service, payment-service -> api-gateway.
