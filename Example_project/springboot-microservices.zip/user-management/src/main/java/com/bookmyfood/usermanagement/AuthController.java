package com.bookmyfood.usermanagement;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
  record LoginReq(String username, String password) {}
  record LoginRes(String token, String username, String roles) {}
  @PostMapping("/login")
  public LoginRes login(@RequestBody LoginReq req) {
    return new LoginRes("DEMO_TOKEN", req.username(), "USER");
  }
  @PostMapping("/register")
  public Map<String, Object> register(@RequestBody Map<String, Object> user) {
    return user;
  }
  @GetMapping("/me")
  public Map<String, Object> me(@RequestHeader(value="Authorization", required=false) String auth) {
    return Map.of("username","demo","roles","USER","token", auth);
  }
}
