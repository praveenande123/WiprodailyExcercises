package com.bookmyfood.paymentservice;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {
  @GetMapping("/{orderId}")
  public Map<String,Object> byOrder(@PathVariable String orderId) {
    return Map.of("orderId", orderId, "status", "SUCCESS");
  }
}
