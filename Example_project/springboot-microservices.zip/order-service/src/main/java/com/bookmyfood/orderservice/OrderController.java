package com.bookmyfood.orderservice;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/order")
public class OrderController {
  record Item(String foodItemId, int qty) {}
  record OrderReq(List<Item> items) {}
  record OrderRes(String orderId, String status) {}
  @PostMapping
  public OrderRes create(@RequestBody OrderReq req) {
    String id = UUID.randomUUID().toString();
    return new OrderRes(id, "PAYMENT_PENDING");
  }
  @GetMapping("/{id}")
  public Map<String,Object> byId(@PathVariable String id) {
    return Map.of("id", id, "status", "PAID");
  }
  @GetMapping("/my")
  public List<Map<String,Object>> my() {
    return List.of(Map.of("id", UUID.randomUUID().toString(), "status", "PAID"));
  }
}
