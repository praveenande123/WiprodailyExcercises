package com.bookmyfood.foodservice;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/food")
public class FoodController {
  record FoodItem(String id, String name, String description, double price, int availableQty) {}
  static List<FoodItem> items = new ArrayList<>(List.of(
      new FoodItem(UUID.randomUUID().toString(), "Pizza", "Cheese Pizza", 299.0, 20),
      new FoodItem(UUID.randomUUID().toString(), "Burger", "Veg Burger", 149.0, 40)
  ));
  @GetMapping public List<FoodItem> all() { return items; }

  record ReserveItem(String foodItemId, int qty) {}
  record ReserveReq(List<ReserveItem> items) {}
  record ReserveRes(boolean ok, double totalAmount) {}
  @PostMapping("/reserve")
  public ReserveRes reserve(@RequestBody ReserveReq req) {
    double total = 0.0;
    for (ReserveItem it: req.items()) { total += 100.0 * it.qty(); }
    return new ReserveRes(true, total);
  }
}
